<?php
define("Pi", 3.14159);
?>
